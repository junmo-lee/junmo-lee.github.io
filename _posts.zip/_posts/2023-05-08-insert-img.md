---
layout: post
#title: "None"
date: 2023-05-08
description: "None"
categories: blog
tags:
- writing
- None 
---

![](a.png)

< : io input > : io oupute

mac clipborad
pbcopy : 명령어 결과를 클립보드 복사
cat a.txt | pbcopy

pbpaste : 클립보드 내용을 출력
pbpaste > b.txt

파인더에서 현재 폴더 or 선택한거 위치 복사 : 옵션키 누르고 → 복붙(커맨드 + c) 

.obsidian 으로 valt마다 테마부터 플러그인까지 다 다름 ㄷㄷ

블로그 루트에 마크다운 넣으면 그대로 들어감 근데 메인화면에는 안뜸..
→ 

\_site 에는 .html만 들어감, 바로 넣어도 될듯?
→ .html에 css 가 들어간 형태

public 제대로 들어감

github에 push 할때는 깃허브에서 빌드함 → 로컬에서 다하고 넣어도 되나?

눈에 띄는거 anki 랑 todolist 연동가능
노션도 api 쓰면 연동가능

typeora도 나쁘지 않은데
이것저것 만질수 있는게 많아서 좋음

### 노션이랑 비슷하게 사용하기
하이라이터 
폴더 icon
밑에 cMaue
Obsidian_to_Anki : 옵시디언과 안키 연동
Auto Link Title : 링크만 붙어넣으면 제목을 알아서 달아 하이퍼링크로
Text Format : 다 대문자로, 소문자로, Capitalize(단어앞만 대문자로) 변경, 팔레트 사용



```
---
layout: post
# title: "None"
date: 2023-05-08
description: "None"
categories: blog
tags:
- writing
- None 
---
```
되던거
[YAML Checker - The YAML Syntax Validator](https://yamlchecker.com/) 이걸로 확인해보기
딱 붙여서 써야이 알아먹음
있어야지 바꿔줌...
title : 없으면 마크다운 폴더의 다음으로 들어감

실제 페이지에서는
제목
날짜 in 카테고리/들 on 테그,들 형태로 나감


문제점 : 로컬 이미지 시작을 /부터 안해서 인식을 못함...
옵시디언 이미지 폴더 → 이미지 레포지토리 → 이미지 url은 마크다운으로

https://github.com/mmistakes/minimal-mistakes 한번써보기

![](https://images.unsplash.com/photo-1573865526739-10659fec78a5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2F0fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=800&q=60)


![](img/b.png)