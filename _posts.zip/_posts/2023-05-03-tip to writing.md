---
layout: post
#title: "None"
date: 2023-05-03
description: "None"
categories: blog
tags:
- writing
- None 
---
url 은 항상 하이퍼링크 형태로
obsidian의 daily note를 활용하기
템플릿 만들어놓기
tag와 category 구현하기

 Address already in use error 
 -   sudo lsof -i :4000
 -  kill -9 <PID>

라이선스 관련 : jekyll → mit, 테마 → GNU GPL 3

고민 : jekyll 태그는 []를 붙여야 하는데 obsidian 태그는 그런거 없음
→ jekyll은 카테고리, obsidian은 태그로 분류

둘다 yaml, 여러개 있을 때 
-
-
로 표현

[metadata관련](https://jekyllrb.com/docs/front-matter/)

### permalink
If you need your processed blog post URLs to be something other than the site-wide style (default `/year/month/day/title.html`), then you can set this variable and it will be used as the final URL.

[metadata 기본값 설정](https://jekyllrb.com/docs/configuration/front-matter-defaults/)


學而時習之 不亦說乎 학이시습지 불역열호

배우고 때맞춰 그것을 익힌다면

또한 기쁘지 아니한가?

  

知之者不如好之者 好之者不如樂之者

지지자 불여호지자 호지자 불여락지자

  

(어떤 사실을)

【아는 사람은 그것을 좋아하는 사람만 못하고,좋아하는 사람은 즐기는 사람만 못하다.】

  

「안다는 것은 진리(眞理)가 있다는 것을 아는 것이다.

좋아한다는 것은 좋아만 했지 완전(完全)히 얻지 못한 것이다.

즐긴다는 것은 완전(完全)히 얻어서 이를 즐긴다는 것이다.」